# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Hover — ``textDocument/hover`` for builtins, types, namespaces, and locals.

Public handler: :func:`handle_hover`. Resolves the identifier under the cursor
(and optional ``module.member`` form) in this order: namespace prefix, type /
qualifier, builtin metadata, user enums, user declarations, then
:data:`~pynescript.langserver.providers.completion_items.PINE_KEYWORDS`.
"""

from __future__ import annotations

import re

from typing import Any

from lsprotocol import types as lsp

from pynescript.ast import node as ast
from pynescript.langserver.analysis import Symbol
from pynescript.langserver.analysis import SymbolIndex
from pynescript.langserver.analysis import ensure_symbol_index
from pynescript.langserver.protocol.utils import get_identifier_segment_at_position
from pynescript.langserver.protocol.utils import in_comment_or_string
from pynescript.langserver.providers.builtin_metadata import get_builtin
from pynescript.langserver.providers.completion_items import PINE_KEYWORDS
from pynescript.langserver.providers.completion_items import collect_user_enums
from pynescript.langserver.providers.docs_card import format_docs_card
from pynescript.langserver.providers.docs_card import format_named_table
from pynescript.langserver.providers.docs_card import pine_v6_docs_link


_KEYWORD_DOCS = dict(PINE_KEYWORDS)

_TYPE_DOCS: dict[str, str] = {
    "int": "Integer numeric value.",
    "float": "Floating-point numeric value.",
    "bool": "Boolean value (`true` or `false`).",
    "string": "Text value.",
    "color": "RGBA color value.",
    "array": "Ordered collection (`array.new<type>()`, `array.get`).",
    "matrix": "Two-dimensional collection (`matrix.new<type>()`).",
    "map": "Key/value collection (`map.new<key, value>()`).",
    "line": "Drawing line object (`line.new`).",
    "linefill": "Fill between two lines (`linefill.new`, `line.fill`).",
    "label": "Drawing label object (`label.new`).",
    "box": "Drawing box object (`box.new`).",
    "table": "Drawing table object (`table.new`).",
    "polyline": "Multi-point drawing object (`polyline.new`).",
}

_QUALIFIER_DOCS: dict[str, str] = {
    "series": "The value may change from bar to bar.",
    "simple": "The value is fixed for a script execution (not bar-to-bar).",
    "const": "The value is known at compile time.",
    "input": "The value comes from a script input.",
    "var": "Initialized once and kept across bars.",
    "varip": "Like `var`, but also updates on every intra-bar tick.",
}

_MODE_QUALIFIERS = frozenset({"var", "varip"})

# Built-in variables are not callables, so they are absent from the function
# metadata catalog. Keep a small authoritative table for hover.
_BUILTIN_VAR_DOCS: dict[str, tuple[str, str]] = {
    "open": ("series float", "Open price of the current bar."),
    "high": ("series float", "High price of the current bar."),
    "low": ("series float", "Low price of the current bar."),
    "close": ("series float", "Close price of the current bar."),
    "volume": ("series float", "Volume of the current bar."),
    "hl2": ("series float", "Midpoint of the current bar's high and low."),
    "hlc3": ("series float", "Average of the current bar's high, low, and close."),
    "ohlc4": ("series float", "Average of the current bar's open, high, low, and close."),
    "time": ("series int", "UNIX timestamp (milliseconds) of the current bar's open."),
    "time_close": ("series int", "UNIX timestamp (milliseconds) of the current bar's close."),
    "bar_index": ("series int", "Zero-based index of the current bar."),
    "last_bar_index": ("series int", "Index of the last bar in the dataset."),
    "na": ("na", "Pine's missing-value literal."),
}

# Module names shown when the cursor is on the left of ``module.member``.
_NAMESPACE_DOCS: dict[str, str] = {
    "ta": "Technical-analysis functions (`ta.sma`, `ta.ema`, `ta.rsi`, …).",
    "math": "Mathematical functions (`math.abs`, `math.max`, `math.log`, …).",
    "str": "String helpers (`str.tostring`, `str.format`, …).",
    "strategy": "Strategy orders, positions, and properties.",
    "input": "Script input widgets (`input.int`, `input.float`, …).",
    "request": "Data requests from other contexts (`request.security`, …).",
    "color": "Color constants and helpers (`color.new`, `color.rgb`, `color.red`, …).",
    "array": "Array helpers (`array.new`, `array.get`, `array.push`, …).",
    "matrix": "Matrix helpers (`matrix.new`, `matrix.get`, …).",
    "map": "Map helpers (`map.new`, `map.get`, `map.put`, …).",
    "line": "Line drawings (`line.new`, `line.fill`, `line.set_xy1`, …).",
    "linefill": "Fill between two lines (`linefill.new`, `linefill.delete`, …).",
    "label": "Label drawings (`label.new`, `label.set_text`, …).",
    "box": "Box drawings (`box.new`, `box.set_bgcolor`, …).",
    "table": "Table drawings (`table.new`, `table.cell`, …).",
    "polyline": "Polyline drawings (`polyline.new`, `polyline.delete`, …).",
    "ticker": "Ticker constructors (`ticker.new`, `ticker.heikinashi`, …).",
    "timeframe": "Timeframe helpers (`timeframe.period`, `timeframe.change`, …).",
    "chart": "Chart context (`chart.bg_color`, `chart.point`, …).",
    "log": "Script log helpers (`log.info`, `log.warning`, `log.error`).",
    "alert": "Alert helpers (`alert()`, `alertcondition`, frequency constants).",
    "syminfo": "Symbol metadata (`syminfo.ticker`, `syminfo.tickerid`, …).",
    "barstate": "Bar-state flags (`barstate.islast`, `barstate.ishistory`, …).",
    "session": "Session helpers (`session.ismarket`, `session.regular`, …).",
}

_SNIPPET_PLACEHOLDER = re.compile(r"\$\{(\d+):([^}]+)\}|\$\{(\d+)\}|\$(\d+)")

# Known Pine library annotation tags. Any other ``//`` line inside an
# annotation block is Markdown continuation content.
_KNOWN_ANNOTATION_TAGS = frozenset(
    {
        "version",
        "description",
        "function",
        "returns",
        "type",
        "variable",
        "param",
        "field",
        "enum",
        "strategy_alert_message",
    }
)

# Tags whose content is the node's description (function / type / variable).
_DESCRIPTION_TAGS = frozenset({"function", "type", "variable", "description", "enum"})


def _split_annotation_tag(body: str) -> tuple[str, str] | None:
    """Parse ``@tag rest`` from a stripped comment line.

    Character scan instead of ``@\\s*([A-Za-z_]+)(?:\\s+(.*))?$`` so hover
    does not run a user-controlled regex (CodeQL ``py/polynomial-redos``).
    """
    if not body.startswith("@"):
        return None
    i = 1
    n = len(body)
    while i < n and body[i] in " \t":
        i += 1
    start = i
    while i < n and (("A" <= body[i] <= "Z") or ("a" <= body[i] <= "z") or body[i] == "_"):
        i += 1
    if i == start:
        return None
    return body[start:i], body[i:].lstrip(" \t")


def handle_hover(
    params: lsp.HoverParams,
    source: str | None,
    tree: Any | None = ...,
    cache: dict[str, Any] | None = None,
    analysis: SymbolIndex | None = None,
) -> lsp.Hover | None:
    """Return markdown hover for a symbol at the cursor, or ``None``.

    Args:
        params: Client hover params (document URI + position).
        source: Document text, or ``None``.
        tree: Pre-parsed AST from the workspace cache. Pass ``None`` when the
            workspace already failed to parse. Omit (default ``...``) to parse
            from *source*.
        cache: Optional per-document-version memo (the workspace
            ``feature_cache``). Caches the user-declaration walk — without it
            every hover re-walks the whole AST.
        analysis: Pre-built symbol index for *tree*.

    Returns:
        :class:`~lsprotocol.types.Hover` with docs, or ``None`` if the
        symbol is unknown / out of range.
    """
    position = params.position

    if not source:
        return None

    lines = source.split("\n")
    if position.line >= len(lines):
        return None

    if in_comment_or_string(source, position.line, position.character):
        return None

    line_text = lines[position.line]
    segment, seg_start, seg_end, word = get_identifier_segment_at_position(source, position.line, position.character)
    if not word:
        return None

    # Scope-aware symbols and members win over namespace/type/builtin cards so
    # a local variable named ``color`` or a UDT field is not described as a
    # builtin namespace.
    index = ensure_symbol_index(source, tree, analysis)
    if index is not None:
        member = index.member_at(position.line, position.character)
        if member is not None:
            if member.symbol is not None:
                return _build_symbol_hover(member.symbol, source, position.line, seg_start, seg_end)
            if member.kind == "constructor":
                return _build_constructor_hover(member, position.line, seg_start, seg_end)
            if member.builtin_name:
                builtin = _hover_builtin(member.builtin_name, line_text, seg_start, position.line, seg_end)
                if builtin is not None:
                    return builtin
        symbol = index.symbol_at(position.line, position.character)
        if symbol is not None:
            return _build_symbol_hover(symbol, source, position.line, seg_start, seg_end)

    ns_hover = _hover_namespace(segment, word, line_text, position.line, seg_start, seg_end)
    if ns_hover is not None:
        return ns_hover

    type_hover = _hover_type_or_qualifier(segment, line_text, seg_end, position.line, seg_start)
    if type_hover is not None:
        return type_hover

    # The library declaration is a builtin-shaped call; prefer a script-level
    # //@description card when one exists.
    resolved = _resolve_tree(source, tree)
    if word == "library":
        library_hover = _hover_library(word, resolved, source, position.line, seg_start, seg_end)
        if library_hover is not None:
            return library_hover

    # User enums get a richer member-aware card than the generic decl card.
    enums = collect_user_enums(resolved, source)
    enum_hover = _hover_user_enum(word, enums, position.line, seg_start, seg_end)
    if enum_hover is not None:
        return enum_hover

    decl_info = _lookup_user_decl(segment, resolved, source, cache)

    builtin_hover = _hover_builtin(word, line_text, seg_start, position.line, seg_end)
    if builtin_hover is not None:
        # User-defined functions/methods/types shadow builtin metadata so
        # library ``//@function`` docs render for colliding names (e.g. ``bb``).
        if decl_info is not None and decl_info.get("kind") in {"function", "method", "type"}:
            return _build_user_decl_hover(decl_info, position.line, seg_start, seg_end)
        return builtin_hover

    if decl_info is not None:
        return _build_user_decl_hover(decl_info, position.line, seg_start, seg_end)

    builtin_var = _BUILTIN_VAR_DOCS.get(segment)
    if builtin_var is not None and not _followed_by_paren(line_text, seg_end):
        type_label, brief = builtin_var
        return _markdown_hover(
            f"{segment}: {type_label}",
            brief,
            position.line,
            seg_start,
            seg_end,
            kind="variable",
        )

    return _hover_keyword(segment, position.line, seg_start, seg_end)


def _build_symbol_hover(
    symbol: Symbol,
    source: str,
    line: int,
    start: int,
    end: int,
) -> lsp.Hover:
    """Build a hover card for a symbol from the static analysis index."""
    if symbol.kind in {"enum", "enum_member"}:
        enum_name = symbol.container if symbol.kind == "enum_member" else symbol.name
        members = []
        # The symbol does not carry the enum body; walk the enum declaration.
        node = symbol.node
        if symbol.kind == "enum_member" and isinstance(symbol.scope.node, ast.EnumDef):
            node = symbol.scope.node
        if isinstance(node, ast.EnumDef):
            for stmt in node.body:
                if isinstance(stmt, ast.Assign) and isinstance(stmt.target, ast.Name):
                    members.append({"name": stmt.target.id, "value": None})
        enum_info = {
            "name": enum_name,
            "members": members,
            "export": symbol.export,
        }
        member = symbol.name if symbol.kind == "enum_member" else None
        return _build_enum_hover(enum_info, member=member, line=line, start=start, end=end)

    if symbol.kind in {"param", "import"}:
        annotations = list(symbol.annotations)
    else:
        comment_block = _extract_comment_block(source.split("\n"), getattr(symbol.node, "lineno", None))
        # The AST keeps only ``//@tag`` lines (not Markdown continuation
        # lines), so prefer the full source comment block when present.
        annotations = comment_block or list(symbol.annotations)
    signature = symbol.signature or symbol.name
    info: dict[str, Any] = {
        "kind": symbol.kind,
        "signature": signature,
        "annotations": annotations,
    }
    hover = _build_user_decl_hover(info, line, start, end)
    extra: list[str] = []
    if symbol.type_label and symbol.type_label not in signature:
        extra.append(f"**Type:** `{symbol.type_label}`")
    if symbol.container:
        extra.append(f"**Member of** `{symbol.container}`")
    if extra:
        content = hover.contents
        if isinstance(content, lsp.MarkupContent):
            content.value = content.value.rstrip() + "\n\n" + "\n\n".join(extra) + "\n"
    return hover


def _build_constructor_hover(
    member: Any,
    line: int,
    start: int,
    end: int,
) -> lsp.Hover:
    """Hover for ``Type.new(...)`` constructors."""
    node = getattr(member, "node", None)
    type_name = ""
    value = getattr(node, "value", None)
    if isinstance(value, ast.Name):
        type_name = value.id or ""
    signature = f"{type_name}.new(...)" if type_name else "new(...)"
    brief = f"Create a new `{type_name}` value." if type_name else "Create a new user-defined value."
    return _markdown_hover(signature, brief, line, start, end, kind="constructor")


def _followed_by_paren(line_text: str, end: int) -> bool:
    return line_text[end:].lstrip().startswith("(")


def _markdown_hover(
    fence: str,
    brief: str,
    line: int,
    start: int,
    end: int,
    *,
    kind: str = "",
    sections: list[str] | None = None,
    footer: str = "",
) -> lsp.Hover:
    return lsp.Hover(
        contents=lsp.MarkupContent(
            kind=lsp.MarkupKind.Markdown,
            value=format_docs_card(
                kind=kind,
                fence=fence,
                body=brief,
                sections=sections,
                footer=footer,
            ),
        ),
        range=lsp.Range(
            start=lsp.Position(line=line, character=start),
            end=lsp.Position(line=line, character=end),
        ),
    )


def _hover_namespace(
    segment: str,
    word: str,
    line_text: str,
    line: int,
    start: int,
    end: int,
) -> lsp.Hover | None:
    """Hover when the cursor is on a module name (`ta` in `ta.sma`)."""
    brief = _NAMESPACE_DOCS.get(segment)
    if brief is None:
        return None
    # ``syminfo.ticker`` has a member segment named ``ticker``; that is a
    # property, not the ticker namespace. Only the head segment can be a
    # namespace.
    if word != segment and not word.startswith(segment + "."):
        return None
    dotted = word.startswith(segment + ".") or (end < len(line_text) and line_text[end] == ".")
    if not dotted:
        # Bare `ta` / `math` still document the module. Types that share a
        # name (`line`, `array`, `color`) and callables (`strategy(`, `input(`)
        # fall through to type / builtin hover.
        if _followed_by_paren(line_text, end) or segment in _TYPE_DOCS or segment in ("strategy", "input"):
            return None
    return _markdown_hover(segment, brief, line, start, end, kind="namespace")


def _hover_type_or_qualifier(
    segment: str,
    line_text: str,
    end: int,
    line: int,
    start: int,
) -> lsp.Hover | None:
    """Hover for a type or qualifier that is not being called as a function."""
    if _followed_by_paren(line_text, end):
        return None
    if segment in _TYPE_DOCS:
        return _markdown_hover(segment, _TYPE_DOCS[segment], line, start, end, kind="type")
    if segment in _QUALIFIER_DOCS:
        kind = "mode" if segment in _MODE_QUALIFIERS else "qualifier"
        return _markdown_hover(segment, _QUALIFIER_DOCS[segment], line, start, end, kind=kind)
    return None


def _lookup_user_decl(
    name: str,
    tree: Any | None,
    source: str,
    cache: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Return the collected declaration info for *name*, or ``None``."""
    if not name or tree is None:
        return None
    try:
        if cache is not None and "user_decls" in cache:
            decls = cache["user_decls"]
        else:
            decls = _collect_user_decls(tree, source)
            if cache is not None:
                cache["user_decls"] = decls
    except Exception:
        return None
    result = decls.get(name)
    return result if isinstance(result, dict) else None


def _strip_comment_prefix(line: str) -> str | None:
    """Return the text after ``//`` (one leading space removed), or ``None``.

    Trailing whitespace is preserved: Pine Markdown uses two trailing spaces to
    force a line break.
    """
    text = line.lstrip()
    if not text.startswith("//"):
        return None
    body = text[2:]
    if body.startswith(" "):
        body = body[1:]
    return body


def _extract_comment_block(lines: list[str], lineno: int | None) -> list[str]:
    """Return the contiguous ``//`` comment block immediately above *lineno*.

    Args:
        lines: Document text split by ``\\n``.
        lineno: 1-based declaration line, or ``None``.

    Returns:
        Raw comment lines (top-to-bottom), or ``[]`` when the line above the
        declaration is not a ``//`` comment.
    """
    if not lines or not lineno:
        return []
    idx = lineno - 2
    if idx < 0 or not lines[idx].lstrip().startswith("//"):
        return []
    start = idx
    while start > 0 and lines[start - 1].lstrip().startswith("//"):
        start -= 1
    return lines[start : idx + 1]


def _extract_comment_block_at(lines: list[str], idx: int) -> list[str]:
    """Return the contiguous ``//`` comment block containing line *idx*."""
    if not lines or idx < 0 or idx >= len(lines) or not lines[idx].lstrip().startswith("//"):
        return []
    start = idx
    while start > 0 and lines[start - 1].lstrip().startswith("//"):
        start -= 1
    end = idx
    while end + 1 < len(lines) and lines[end + 1].lstrip().startswith("//"):
        end += 1
    return lines[start : end + 1]


def _parse_annotation_entries(block: list[str] | None) -> list[tuple[str, str | None, str]]:
    """Parse a ``//`` comment block into ``(tag, name, content)`` entries.

    A known tag line starts a new entry (``@function``, ``@param name …``,
    ``@returns``, …); every following plain ``//`` line is Markdown
    continuation content for that tag. Markdown (headings, lists, code fences,
    blockquotes, tables, links, inline formatting, and two-space line breaks)
    is preserved verbatim so the hover renders it.

    Args:
        block: Raw comment lines (each starting with ``//``), or ``None``.

    Returns:
        Ordered ``(tag, name, content)`` entries. ``name`` is set for
        ``param`` / ``field``. Empty when the block has no known tag.
    """
    entries: list[list[Any]] = []
    current: list[Any] | None = None
    for raw in block or []:
        body = _strip_comment_prefix(raw)
        if body is None:
            continue
        parsed = _split_annotation_tag(body.lstrip())
        tag = parsed[0].lower() if parsed else ""
        if parsed and tag in _KNOWN_ANNOTATION_TAGS:
            if current is not None:
                entries.append(current)
            rest = parsed[1] or ""
            if tag in {"param", "field"}:
                parts = rest.split(None, 1)
                name = parts[0] if parts else ""
                desc = parts[1] if len(parts) > 1 else ""
                current = [tag, name, [desc] if desc else []]
            else:
                current = [tag, None, [rest] if rest else []]
        elif current is not None:
            current[2].append(body)
    if current is not None:
        entries.append(current)
    return [(entry[0], entry[1], "\n".join(entry[2]).rstrip("\n")) for entry in entries]


def _annotation_sections(
    entries: list[tuple[str, str | None, str]],
) -> tuple[str | None, list[tuple[str, str]], str | None, list[tuple[str, str]]]:
    """Split annotation entries into description, params, returns, and fields."""
    description: str | None = None
    returns: str | None = None
    params: list[tuple[str, str]] = []
    fields: list[tuple[str, str]] = []
    for tag, field_name, content in entries:
        if tag in _DESCRIPTION_TAGS:
            if content:
                description = content
        elif tag == "param" and field_name:
            params.append((field_name, content))
        elif tag == "field" and field_name:
            fields.append((field_name, content))
        elif tag == "returns" and content:
            returns = content
    return description, params, returns, fields


def _format_named_list(title: str, items: list[tuple[str, str]]) -> str:
    """Render a Markdown table (or bullets) of ``name``/``description`` pairs."""
    return format_named_table(title, items)


def _build_user_decl_hover(info: dict[str, Any], line: int, start: int, end: int) -> lsp.Hover:
    """Build a Markdown hover card from a declaration's annotations.

    The card mirrors TradingView's library hover: a fenced signature, then the
    ``//@function`` / ``//@type`` / ``//@variable`` description rendered as
    Markdown, followed by ``//@field``, ``//@param``, and ``//@returns``
    sections. Without annotations it falls back to a one-line note.
    """
    kind = info.get("kind", "declaration")
    signature = info.get("signature") or info.get("name") or kind
    entries = _parse_annotation_entries(info.get("annotations"))
    description, params, returns, fields = _annotation_sections(entries)

    sections: list[str] = []
    if fields:
        sections.append(_format_named_list("Fields", fields))
    if params:
        sections.append(_format_named_list("Parameters", params))
    if returns:
        sections.append(f"**Returns:** {returns}")
    body = description or (f"User-defined {kind}." if not sections else "")
    return lsp.Hover(
        contents=lsp.MarkupContent(
            kind=lsp.MarkupKind.Markdown,
            value=format_docs_card(
                kind=str(kind),
                fence=str(signature),
                body=body,
                sections=sections,
            ),
        ),
        range=lsp.Range(
            start=lsp.Position(line=line, character=start),
            end=lsp.Position(line=line, character=end),
        ),
    )


def _hover_library(
    word: str,
    tree: Any | None,
    source: str | None,
    line: int,
    start: int,
    end: int,
) -> lsp.Hover | None:
    """Hover the ``library`` declaration using the script-level ``//@description``."""
    if word != "library" or tree is None or not source:
        return None
    raw = getattr(tree, "annotations", None) or []
    if not any("description" in item for item in raw):
        return None
    lines = source.split("\n")
    for idx, text in enumerate(lines):
        if not re.match(r"^\s*//\s*@\s*description\b", text):
            continue
        entries = _parse_annotation_entries(_extract_comment_block_at(lines, idx))
        description = next(
            (content for tag, _name, content in entries if tag == "description" and content),
            None,
        )
        if description:
            return _markdown_hover("library", description, line, start, end, kind="library")
    return None


def _collect_user_decls(tree: Any, source: str) -> dict[str, dict[str, Any]]:
    """Map identifier → first declaration (kind, source signature, annotations)."""
    found: dict[str, dict[str, Any]] = {}
    # Split once — a per-declaration split is O(decls x doc-size).
    lines = source.split("\n") if source else []

    def add(name: str | None, kind: str, node: Any, fallback: str) -> None:
        if not name or name in found:
            return
        lineno = getattr(node, "lineno", None)
        snippet = _snippet_from_lines(lines, lineno)
        found[name] = {
            "kind": kind,
            "signature": snippet or fallback,
            # Full contiguous comment block (tag + Markdown continuation lines).
            "annotations": _extract_comment_block(lines, lineno),
        }

    def walk(node: Any) -> None:
        if node is None:
            return
        if isinstance(node, ast.FunctionDef) and node.name:
            kind = "method" if node.method else "function"
            add(node.name, kind, node, _function_fallback(node))
        elif isinstance(node, ast.TypeDef) and node.name:
            export = "export " if node.export else ""
            add(node.name, "type", node, f"{export}type {node.name}")
        elif isinstance(node, ast.EnumDef) and node.name:
            export = "export " if node.export else ""
            add(node.name, "enum", node, f"{export}enum {node.name}")
        elif isinstance(node, ast.Assign) and isinstance(node.target, ast.Name):
            add(node.target.id, "variable", node, node.target.id)
        elif isinstance(node, ast.Assign) and isinstance(node.target, ast.Tuple):
            for elt in node.target.elts or []:
                if isinstance(elt, ast.Name):
                    add(elt.id, "variable", node, elt.id)

        for field in getattr(node, "_fields", ()) or ():
            value = getattr(node, field, None)
            if value is None:
                continue
            if isinstance(value, list):
                for child in value:
                    if child is not None and hasattr(child, "_fields"):
                        walk(child)
            elif hasattr(value, "_fields"):
                walk(value)

    walk(tree)
    return found


def _function_fallback(node: ast.FunctionDef) -> str:
    args: list[str] = []
    for param in node.args or []:
        pname = getattr(param, "name", None)
        if pname:
            args.append(str(pname))
    prefix = ""
    if node.export:
        prefix += "export "
    if node.method:
        prefix += "method "
    return f"{prefix}{node.name}({', '.join(args)}) =>"


def _line_snippet(source: str, lineno: int | None) -> str:
    if not source or not lineno:
        return ""
    return _snippet_from_lines(source.split("\n"), lineno)


def _snippet_from_lines(lines: list[str], lineno: int | None) -> str:
    """Stripped source line *lineno* (1-based) from a pre-split line list."""
    if not lines or not lineno:
        return ""
    idx = lineno - 1
    if 0 <= idx < len(lines):
        return lines[idx].strip()
    return ""


def _hover_builtin(word: str, line_text: str, start: int, line: int, end: int) -> lsp.Hover | None:
    """Resolve a builtin from the full word, leaf, or preceding ``module.``."""
    called = _followed_by_paren(line_text, end)
    builtin_info = get_builtin(word)
    if builtin_info:
        return _build_builtin_hover(builtin_info, line, start, end, called=called)

    if "." in word:
        leaf = word.rsplit(".", 1)[-1]
        for candidate in (word, leaf):
            builtin_info = get_builtin(candidate)
            if builtin_info:
                return _build_builtin_hover(builtin_info, line, start, end, called=called)

    text_before = line_text[:start]
    words_before = text_before.rstrip().split()
    if words_before:
        last_word = words_before[-1]
        if last_word.endswith("."):
            module = last_word.rstrip(".")
            builtin_info = get_builtin(f"{module}.{word}")
            if builtin_info:
                return _build_builtin_hover(builtin_info, line, start, end, called=called)
    return None


def _resolve_tree(source: str | None, tree: Any | None) -> Any | None:
    if tree is not ...:
        return tree
    if not source:
        return None
    try:
        from pynescript.ast.helper import parse

        return parse(source)
    except Exception:
        return None


def _hover_user_enum(
    word: str,
    enums: dict[str, dict[str, Any]],
    line: int,
    start: int,
    end: int,
) -> lsp.Hover | None:
    """Hover for a user enum type or ``Enum.member`` path."""
    if word in enums:
        return _build_enum_hover(enums[word], member=None, line=line, start=start, end=end)
    if "." in word:
        enum_name, _, member = word.partition(".")
        info = enums.get(enum_name)
        if info is not None:
            return _build_enum_hover(info, member=member, line=line, start=start, end=end)
    return None


def _hover_keyword(word: str, line: int, start: int, end: int) -> lsp.Hover | None:
    brief = _KEYWORD_DOCS.get(word)
    if brief is None:
        return None
    return _markdown_hover(word, brief, line, start, end, kind="keyword")


def _build_enum_hover(
    info: dict[str, Any],
    member: str | None,
    line: int,
    start: int,
    end: int,
) -> lsp.Hover:
    name = info.get("name", "")
    export = "export " if info.get("export") else ""
    lines = [f"{export}enum {name}"]
    matched = None
    for item in info.get("members", []):
        mname = item.get("name", "")
        value = item.get("value")
        decl = f"    {mname}" if value is None else f"    {mname} = {value!r}"
        lines.append(decl)
        if member and mname == member:
            matched = item
    if member and matched is None:
        # Unknown member still shows the enum type.
        pass
    detail = "\n".join(lines)
    if member and matched is not None:
        value = matched.get("value")
        brief = f"Member of user enum `{name}`."
        if value is not None:
            brief += f" Value: `{value!r}`."
        kind = "member"
    else:
        brief = "User-defined enum."
        kind = "enum"
    return _markdown_hover(detail, brief, line, start, end, kind=kind)


def _signature_from_info(info: dict) -> str:
    """Prefer a real signature line; fall back to ``detail`` / label."""
    label = (info.get("label") or "").strip()
    detail = (info.get("detail") or "").strip()
    snippet = (info.get("snippet") or "").strip()
    if detail and not detail.endswith("(...)"):
        return detail
    if snippet:
        cleaned = _SNIPPET_PLACEHOLDER.sub(
            lambda m: m.group(2) if m.group(2) else "",
            snippet,
        )
        if cleaned and "param" not in cleaned.lower() and cleaned not in {label, f"{label}(...)"}:
            return cleaned
    return detail or label


def _format_params(info: dict) -> str:
    """Render a Parameters section when metadata includes ``params``."""
    params = info.get("params")
    if params is None:
        params = info.get("parameters")
    if not params:
        return ""
    entries: list[tuple[str, str]] = []
    if isinstance(params, dict):
        entries = [(str(k), "" if v is None else str(v)) for k, v in params.items()]
    elif isinstance(params, list):
        for item in params:
            if isinstance(item, str):
                entries.append((item, ""))
            elif isinstance(item, dict):
                name = item.get("name") or item.get("label") or ""
                if not name:
                    continue
                typ = item.get("type") or ""
                desc = item.get("brief") or item.get("documentation") or item.get("detail") or ""
                extra = f" (`{typ}`)" if typ else ""
                tail = f" — {desc}" if desc else ""
                entries.append((str(name), f"{extra}{tail}"))
    if not entries:
        return ""
    cleaned: list[tuple[str, str]] = []
    for name, desc in entries:
        text = desc.strip()
        if text.startswith("—"):
            text = text.lstrip("— ").strip()
        cleaned.append((name, text))
    return format_named_table("Parameters", cleaned)


def _build_builtin_hover(
    info: dict,
    line: int,
    start: int,
    end: int,
    *,
    called: bool = True,
) -> lsp.Hover:
    """Build a Hover for a builtin function or property.

    Args:
        info: Metadata dict from builtin_metadata.
        line: The line number (0-indexed).
        start: Start character position.
        end: End character position.
        called: Whether the identifier is followed by ``(``. Bare uses of
            overloaded entries (``syminfo.ticker``) get a property card rather
            than a function signature.

    Returns:
        LSP Hover with documentation.
    """
    label = info.get("label", "")
    brief = info.get("brief", "")
    documentation = info.get("documentation", "")
    signature = _signature_from_info(info)
    if called and "(" not in signature:
        signature = f"{label}(...)"
    if not called and "." in label and signature.startswith(label + "("):
        signature = label
        if not brief:
            brief = "Built-in property."

    sections: list[str] = []
    if called:
        params_block = _format_params(info)
        if params_block:
            sections.append(params_block)
    if documentation and documentation != brief:
        sections.append(_format_documentation(documentation))
    examples = _build_examples(info)
    if examples:
        sections.append(examples)
    see_also = _build_see_also(info)
    if see_also:
        sections.append(see_also)
    kind = "function" if called or "(" in signature else "property"
    return _markdown_hover(
        signature,
        brief,
        line,
        start,
        end,
        kind=kind,
        sections=sections,
        footer=_build_docs_link(label),
    )


def _format_documentation(doc: str) -> str:
    """Format documentation text for display."""
    # Take first paragraph if it's long
    paragraphs = doc.split("\n\n")
    first_para = paragraphs[0] if paragraphs else doc
    # Limit to 500 chars
    if len(first_para) > 500:
        first_para = first_para[:497] + "..."
    return first_para


def _build_examples(info: dict) -> str:
    """Build examples section for hover."""
    label = info.get("label", "")
    if not label.startswith(("ta.", "strategy.", "plot")):
        return ""

    examples = {
        "ta.sma": "```pinescript\nplot(ta.sma(close, 14))\n```",
        "ta.ema": "```pinescript\nplot(ta.ema(close, 14))\n```",
        "ta.rsi": "```pinescript\nplot(ta.rsi(close, 14))\n```",
        "ta.macd": "```pinescript\n[macdLine, signalLine, histLine] = ta.macd(close, 12, 26, 9)\nplot(macdLine, color=color.blue)\nplot(signalLine, color=color.orange)\n```",
        "strategy.entry": '```pinescript\nstrategy.entry("Long", strategy.long)\n```',
        "strategy.exit": '```pinescript\nstrategy.exit("Exit", profit=100, loss=50)\n```',
    }

    example = examples.get(label, "")
    if example:
        return f"**Example:**\n{example}\n\n"
    return ""


def _build_see_also(info: dict) -> str:
    """Build 'See also' section."""
    related_map = {
        "ta.sma": ["ta.ema", "ta.rma", "ta.wma"],
        "ta.ema": ["ta.sma", "ta.rma", "ta.wma"],
        "ta.rsi": ["ta.stoch", "ta.mfi"],
        "ta.macd": ["ta.rsi", "ta.bb"],
        "ta.bb": ["ta.macd", "ta.kc"],
        "ta.atr": ["ta.tr"],
        "strategy.entry": ["strategy.exit", "strategy.close"],
    }

    label = info.get("label", "")
    related = related_map.get(label, [])

    if not related:
        return ""

    links = ", ".join(f"`{r}`" for r in related)
    return f"**See also:** {links}\n\n"


def _build_docs_link(name: str) -> str:
    """Markdown link to the public Pine v6 function reference.

    Only dotted builtin labels with a namespace (``ta.sma``,
    ``strategy.entry``, ``line.fill``) get a link. Empty, undotted
    (``sma``), or whitespace-only names return ``""``.
    """
    return pine_v6_docs_link(name)
