# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Pine ``map`` collection type (key-value store).

Defines the runtime :class:`Map` value used by ``map.*`` builtins. Dispatch
handlers live in :mod:`map_evaluator` (:class:`MapBuiltinsMixin`); this module
is the pure data structure only.
"""

from __future__ import annotations

from typing import Any
from typing import Generic
from typing import TypeVar


__all__ = ["Map"]

K = TypeVar("K")
V = TypeVar("V")


class Map(Generic[K, V]):
    """Mutable ordered-preserving key-value map for Pine ``map.*`` operations.

    Backed by a Python ``dict``. Methods mirror reference Pine map semantics
    (``get``/``put``/``remove``/``keys``/``values``/…). Evaluator dispatch is
    in :class:`~pynescript.ast.evaluator.builtins.map_evaluator.MapBuiltinsMixin`.
    """

    def __init__(self):
        """Initialize empty map."""
        self.data: dict[Any, Any] = {}

    # ========== CORE METHODS ==========

    def get(self, key: K) -> V | None:
        """Get value by key, returns None if not found."""
        return self.data.get(key)

    def put(self, key: K, value: V) -> None:
        """Insert or update key-value pair."""
        self.data[key] = value

    def put_all(self, other: Map[K, V]) -> None:
        """Insert all key-value pairs from another map."""
        if not isinstance(other, Map):
            msg = "put_all requires a Map argument"
            raise TypeError(msg)
        self.data.update(other.data)

    def remove(self, key: K) -> V | None:
        """Remove key from map; return prior value or None if missing."""
        if key in self.data:
            return self.data.pop(key)
        return None

    def clear(self) -> None:
        """Remove all entries from map."""
        self.data.clear()

    def contains(self, key: K) -> bool:
        """Check if key exists in map."""
        return key in self.data

    def keys(self) -> list[K]:
        """Get all keys as list."""
        return list(self.data.keys())

    def values(self) -> list[V]:
        """Get all values as list."""
        return list(self.data.values())

    def size(self) -> int:
        """Get number of key-value pairs."""
        return len(self.data)

    def copy(self) -> Map[K, V]:
        """Create shallow copy of map."""
        new_map: Map[K, V] = Map()
        new_map.data = self.data.copy()
        return new_map

    def copy_contents(self) -> dict[Any, Any]:
        """One-level snapshot of map items (realtime rollback)."""
        return self.data.copy()

    def restore_contents(self, snap: dict[Any, Any]) -> None:
        """Restore from :meth:`copy_contents` into this instance."""
        self.data.clear()
        self.data.update(snap)

    def __repr__(self) -> str:
        """String representation."""
        return f"map({self.size()})"
