# Copyright (C) 2024-2026 jango_blockchained
#
# This file is part of pynescript.
#
# pynescript is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pynescript is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with pynescript.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Jupyter Integration for PyneScript.

This module provides Jupyter notebook support for PyneScript:
- IPython magic commands (%pinescript)
- Data helpers for working with Pine Script in notebooks
- Display helpers for visualizing results

Usage in Jupyter:
    from pynescript.ext.jupyter import load_ipython_extension
    load_ipython_extension(ipython)
"""

from __future__ import annotations

import random

from typing import Any
from typing import cast

from pynescript.ast import parse
from pynescript.ast import unparse
from pynescript.ast.linter import lint_script


def load_ipython_extension(ipython: Any) -> None:
    """Load PyneScript magic commands in Jupyter.

    Args:
        ipython: IPython instance
    """
    try:
        from IPython.core.magic import register_cell_magic  # optional dep lazy
    except ImportError:
        msg = "IPython is required for Jupyter integration"
        raise ImportError(msg)  # noqa: B904

    @register_cell_magic
    def pinescript(line: str, cell: str) -> None:
        """Run Pine Script code and display results.

        Usage:
            %%pinescript
            //@version=6
            indicator("My Indicator")
            plot(ta.sma(close, 14))
        """
        warnings = lint_script(cell)
        if warnings:
            print("Lint warnings:")  # noqa: T201
            for w in warnings:
                print(f"  {w}")  # noqa: T201
            print()  # noqa: T201

        try:
            ast = parse(cell)
            result = unparse(ast)
            print("Parsed successfully!")  # noqa: T201
            print("---")  # noqa: T201
            print(result)  # noqa: T201
        except Exception as e:
            print(f"Error: {e}")  # noqa: T201

    ipython.user_ns.update(
        {
            "pine_parse": parse,
            "pine_unparse": unparse,
            "pine_lint": lint_script,
        }
    )


def create_sample_data(
    length: int = 100,
    start_price: float = 100.0,
    volatility: float = 0.02,
    trend: float = 0.0,
) -> dict[str, list[float]]:
    """Create sample OHLCV data for testing Pine Script indicators.

    Args:
        length: Number of bars to generate
        start_price: Starting price
        volatility: Price volatility (0.02 = 2%)
        trend: Price trend per bar

    Returns:
        Dictionary with 'open', 'high', 'low', 'close', 'volume' keys

    Example:
        >>> data = create_sample_data(100, 100, 0.02)
        >>> data['close'][:5]
        [100.0, 101.23, 99.87, 102.15, 101.02]
    """
    close = [start_price]
    for _ in range(length - 1):
        change = random.gauss(trend, volatility) * close[-1]
        close.append(close[-1] + change)

    opens = close[:-1]
    opens.insert(0, start_price)

    highs = [max(o, c) * (1 + random.uniform(0, volatility)) for o, c in zip(opens, close, strict=False)]
    lows = [min(o, c) * (1 - random.uniform(0, volatility)) for o, c in zip(opens, close, strict=False)]

    volumes = [int(random.gauss(1000000, 200000)) for _ in range(length)]

    return {
        "open": opens,
        "high": highs,
        "low": lows,
        "close": close,
        "volume": [float(v) for v in volumes],
    }


def evaluate_indicator(
    code: str,
    data: dict[str, list[float]],
    data_feed: Any = None,
    data_provider: Any = None,
) -> dict[str, Any]:
    """Evaluate a Pine Script indicator with sample data.

    Args:
        code: Pine Script indicator code
        data: OHLCV data dictionary
        data_feed: Optional realtime data feed for request.*
        data_provider: Optional historical provider

    Returns:
        Dictionary of indicator results

    Example:
        >>> data = create_sample_data(100)
        >>> code = '''//@version=6
        ... indicator("SMA")
        ... plot(ta.sma(close, 14))
        ... '''
        >>> result = evaluate_indicator(code, data)
    """
    from pynescript.ast.evaluator import NodeLiteralEvaluator  # avoid potential circular at top

    context = {
        "close": data["close"],
        "open": data["open"],
        "high": data["high"],
        "low": data["low"],
        "volume": data["volume"],
    }
    evaluator = NodeLiteralEvaluator(context=context, data_feed=data_feed, data_provider=data_provider)

    try:
        ast = parse(code)
        evaluator.visit(ast)
    except Exception as e:
        return {"error": str(e)}

    return cast(dict[str, Any], evaluator.context)


def display_indicator_table(
    data: dict[str, list[float]],
    columns: list[str] | None = None,
    rows: int = 20,
) -> Any:
    """Display indicator data as a table in Jupyter.

    Args:
        data: Dictionary of column name to values
        columns: Which columns to display (default: all)
        rows: Number of rows to show

    Returns:
        IPython display object
    """
    try:
        import pandas as pd  # optional dep, lazy import inside func

        df = pd.DataFrame(data)
        if columns:
            df = df[columns]
        return df.head(rows)
    except ImportError:
        print("pandas required for table display. Install with: pip install pandas")  # noqa: T201
        return None


__all__ = [
    "create_sample_data",
    "display_indicator_table",
    "evaluate_indicator",
    "load_ipython_extension",
]
